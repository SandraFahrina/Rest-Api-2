

<?php $__env->startSection('title', 'Tokoo'); ?>

<?php $__env->startSection('content'); ?>
<a href="/items/create" class="card-link">Tambah Item</a>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width: 18rem;">
  <img src="<?php echo e(url('foto')); ?>/<?php echo e($item['gambar']); ?>" class="card-img-top" alt="...">
  <div class="card-body">
  <a href="/items/<?php echo e($item['id']); ?>" class="card-title">Nama  <?php echo e($item['nama']); ?></a>
    <table class="table">
    <tbody>
    <tr>
    <td>Harga</td>
    <td>:</td>
    <td>Rp. <?php echo e($item['harga']); ?></td>
    </tr>
    <tr>
    <td>Stok</td>
    <td>:</td>
    <td><?php echo e($item['stok']); ?></td>
    </tr>
    <tr>
    <td>Ukuran</td>
    <td>:</td>
    <td><?php echo e($item['ukuran']); ?></td>
    </tr>
    </tbody>
    </table>
    <a href="/items/<?php echo e($item['id']); ?>/edit" class="btn btn-primary">Edit Item</a>
    <form action="/items/<?php echo e($item['id']); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
    <button class="btn btn-primary">Hapus</button>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div>
    <?php echo e($items->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatu\resources\views/items/index.blade.php ENDPATH**/ ?>